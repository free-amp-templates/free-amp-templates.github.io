# free-amp-templates.github.io
Free AMP Templates
This website is open-source and free to be downloaded and repurposed but NOT REUSED in its entirety.
If you should find this template helpful in developing your website and/or career, please consider throwing me a bone as a thank-you gesture!
Venmo @austintude or paypal.me/austintude
All the best!
Daniel Bisett
